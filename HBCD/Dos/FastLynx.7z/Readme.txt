FastLynx 2.0 File Transfer Utility
----------------------------------
This copy of FastLynx is set to Default Remote Transfer Mode 
in 'Split Screen Mode' To change to Local Copy Press 
F9(Options) and change Local/Remote setting.

NOTE:
You will need a 
'Null Modem' Data Transfer Serial Cable 
(9 Pin, 25 Pin or Combination to match PC sockets)
 and/or
'Data Transfer' Parallel Cable (or InterLink Printer Cable Converter)
They are available from most Good Computer Stores.
(They are also known as 'LapLink' Cables) 
for Remote Access and File Transfer between PC's

